---
title: kasir-POS Implementasi Plan — Patch Log
latest_patch_id: PATCH-0017
total_entries: 17
---

# PATCHLOG.md — Log Perubahan per Subtask

> **Format:** Prepend-only (entri terbaru ditambahkan paling ATAS, tepat di bawah baris ini).
> Jangan pernah menghapus atau menimpa entri lama.
> **ID:** `PATCH-NNNN` urut naik (4 digit, tidak reset), jadi heading `## PATCH-NNNN`.
> **Wajib diisi setiap kali sebuah subtask (task.subtask, mis. 0.1, 1.2, dst.) selesai dikerjakan.**

<!-- ENTRY BARU DITAMBAHKAN DI SINI (tepat di bawah baris ini, di ATAS entri lama) -->

## PATCH-0017
**Task ID:** 3.3
**Tanggal:** 2026-07-30
**Judul:** Endpoint checkout + fix kode transaksi di response
**Deskripsi:** Response sukses pakai kode TRX asli, bukan ID numerik (fix bug PRD 15.13)
**File Berubah:**
- backend/app/kasir/checkout_endpoint.py
**Bundle Zip:** implementasi_plan/bundles/3.3.zip
**Status:** done
**Catatan:** -


## PATCH-0016
**Task ID:** 3.2
**Tanggal:** 2026-07-30
**Judul:** Service checkout atomic
**Deskripsi:** Gabungkan validasi fail-fast + semantik bonus tetap potong stok, dalam 1 DB transaction
**File Berubah:**
- backend/app/kasir/checkout_service.py
**Bundle Zip:** implementasi_plan/bundles/3.2.zip
**Status:** done
**Catatan:** -


## PATCH-0015
**Task ID:** 3.1
**Tanggal:** 2026-07-30
**Judul:** Endpoint daftar produk kasir
**Deskripsi:** Search produk untuk kasir, sembunyikan stok<=0
**File Berubah:**
- backend/app/kasir/list_produk.py
**Bundle Zip:** implementasi_plan/bundles/3.1.zip
**Status:** done
**Catatan:** -


## PATCH-0014
**Task ID:** 2.5
**Tanggal:** 2026-07-30
**Judul:** Halaman login frontend
**Deskripsi:** UI login dark-theme sesuai token PRD §17, tampilkan sisa percobaan/lockout
**File Berubah:**
- frontend/src/pages/login.tsx
**Bundle Zip:** implementasi_plan/bundles/2.5.zip
**Status:** done
**Catatan:** -


## PATCH-0013
**Task ID:** 2.4
**Tanggal:** 2026-07-30
**Judul:** Middleware otorisasi per-role di setiap endpoint
**Deskripsi:** Validasi role di server untuk semua endpoint, single source access matrix
**File Berubah:**
- backend/app/auth/access_matrix.py
- backend/app/auth/require_role.py
**Bundle Zip:** implementasi_plan/bundles/2.4.zip
**Status:** done
**Catatan:** -


## PATCH-0012
**Task ID:** 2.3
**Tanggal:** 2026-07-30
**Judul:** Session/JWT + idle timeout 60 menit
**Deskripsi:** Idle timeout dikonfigurasi via env SESSION_TIMEOUT
**File Berubah:**
- backend/app/auth/session.py
**Bundle Zip:** implementasi_plan/bundles/2.3.zip
**Status:** done
**Catatan:** -


## PATCH-0011
**Task ID:** 2.2
**Tanggal:** 2026-07-30
**Judul:** Lockout 5x gagal / 5 menit
**Deskripsi:** Counter percobaan gagal per user + auto-lockout 300 detik
**File Berubah:**
- backend/app/auth/lockout.py
**Bundle Zip:** implementasi_plan/bundles/2.2.zip
**Status:** done
**Catatan:** -


## PATCH-0010
**Task ID:** 2.1
**Tanggal:** 2026-07-30
**Judul:** Endpoint login + password hashing
**Deskripsi:** POST /auth/login dengan hashing setara PBKDF2 310k, update last_login
**File Berubah:**
- backend/app/auth/login.py
- backend/app/auth/security.py
**Bundle Zip:** implementasi_plan/bundles/2.1.zip
**Status:** done
**Catatan:** -


## PATCH-0009
**Task ID:** 1.5
**Tanggal:** 2026-07-30
**Judul:** Script migrasi data lama SQLite -> RDBMS baru
**Deskripsi:** One-off migration script + dry-run mode + validasi jumlah baris
**File Berubah:**
- scripts/migrate_legacy_sqlite.py
**Bundle Zip:** implementasi_plan/bundles/1.5.zip
**Status:** done
**Catatan:** -


## PATCH-0008
**Task ID:** 1.4
**Tanggal:** 2026-07-30
**Judul:** Keputusan & migrasi bonus_kasir/transaksi_bonus
**Deskripsi:** Finalisasi apakah bonus_kasir diimplementasikan penuh atau dihapus dari skema
**File Berubah:**
- migrations/0004_bonus_kasir_decision.sql
- implementasi_plan/decisions/0004-bonus-kasir.md
**Bundle Zip:** implementasi_plan/bundles/1.4.zip
**Status:** done
**Catatan:** -


## PATCH-0007
**Task ID:** 1.3
**Tanggal:** 2026-07-30
**Judul:** Migrasi tabel pengeluaran, users, activity_log
**Deskripsi:** Kategori pengeluaran disatukan + CHECK constraint, skema users & audit trail
**File Berubah:**
- migrations/0003_pengeluaran_users_log.sql
**Bundle Zip:** implementasi_plan/bundles/1.3.zip
**Status:** done
**Catatan:** -


## PATCH-0006
**Task ID:** 1.2
**Tanggal:** 2026-07-30
**Judul:** Migrasi tabel transaksi & transaksi_detail
**Deskripsi:** Tambah kolom is_bonus eksplisit, satukan kolom timestamp
**File Berubah:**
- migrations/0002_transaksi.sql
**Bundle Zip:** implementasi_plan/bundles/1.2.zip
**Status:** done
**Catatan:** -


## PATCH-0005
**Task ID:** 1.1
**Tanggal:** 2026-07-30
**Judul:** Migrasi tabel produk, produk_batch, pelanggan
**Deskripsi:** Skema inti inventory + FIFO batch + pelanggan, keputusan dead columns didokumentasikan
**File Berubah:**
- migrations/0001_produk_batch_pelanggan.sql
**Bundle Zip:** implementasi_plan/bundles/1.1.zip
**Status:** done
**Catatan:** -


## PATCH-0004
**Task ID:** 0.4
**Tanggal:** 2026-07-30
**Judul:** Setup environment lokal (docker-compose) & seed data dummy
**Deskripsi:** docker-compose.yml (postgres+redis+backend+frontend) + Dockerfile masing-masing + seed.py bootstrap 3 user role & 3 produk contoh. Syntax & import tervalidasi; 'docker compose up' & eksekusi DB nyata BELUM diverifikasi di sandbox ini (tidak ada docker daemon & instalasi postgres via apt gagal karena mirror 404) -- wajib dites manual di mesin dev sebelum dianggap 'done' penuh.
**File Berubah:**
- docker-compose.yml
- backend/Dockerfile
- frontend/Dockerfile
- backend/scripts/seed.py
- backend/requirements.txt
**Bundle Zip:** implementasi_plan/bundles/0.4.zip
**Status:** done
**Catatan:** Perlu verifikasi manual: docker compose up --build lalu python backend/scripts/seed.py, di lingkungan yang punya Docker.


## PATCH-0003
**Task ID:** 0.3
**Tanggal:** 2026-07-30
**Judul:** Scaffold repo baru & CI dasar
**Deskripsi:** Scaffold backend FastAPI (health endpoint + pytest lulus + ruff bersih) dan frontend React+TS+Vite (tsc build lulus); CI workflow lint+test kedua sisi.
**File Berubah:**
- backend/app/main.py
- backend/app/__init__.py
- backend/__init__.py
- backend/tests/test_health.py
- backend/tests/__init__.py
- backend/requirements.txt
- frontend/package.json
- frontend/index.html
- frontend/src/App.tsx
- frontend/src/main.tsx
- frontend/tsconfig.json
- .github/workflows/ci.yml
**Bundle Zip:** implementasi_plan/bundles/0.3.zip
**Status:** done
**Catatan:** -


## PATCH-0002
**Task ID:** 0.2
**Tanggal:** 2026-07-30
**Judul:** Keputusan tech stack migrasi
**Deskripsi:** ADR: FastAPI+SQLAlchemy+Alembic, React+TS+Vite, PostgreSQL, Recharts, JWT, RQ+Redis
**File Berubah:**
- implementasi_plan/decisions/0002-tech-stack.md
**Bundle Zip:** implementasi_plan/bundles/0.2.zip
**Status:** done
**Catatan:** -


## PATCH-0001
**Task ID:** 0.1
**Tanggal:** 2026-07-30
**Judul:** Setup folder implementasi_plan, status.md, patchlog.md
**Deskripsi:** Inisialisasi status.md dan patchlog.md dari template, verifikasi finish_subtask.py berjalan
**File Berubah:**
- implementasi_plan/status.md
- implementasi_plan/patchlog.md
- implementasi_plan/scripts/finish_subtask.py
**Bundle Zip:** implementasi_plan/bundles/0.1.zip
**Status:** done
**Catatan:** -

